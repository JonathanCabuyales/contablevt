<?php

 // Configura path host
    define('HOST', 'http://localhost/vt/APIVTPROYECTOS/facturaelectronica/libreria_2021');
       


