<!DOCTYPE html>
<html>
<head>
	<title>Crear codigo de Barras PHP - Evilnapsis</title>
</head>
<body>
<center>
<h1>Crear codigo de Barras PHP - Evilnapsis</h1>
<br><br>
<img src="generar.php">
</center>
</body>
</html>