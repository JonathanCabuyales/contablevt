<?php

echo json_encode(date("ddmmyy"));